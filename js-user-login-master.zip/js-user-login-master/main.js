"use strict";
//User Login Javascript



document.getElementById("btn").addEventListener("click", access);

//Event Cammand
function access() {
    
    let user = document.getElementById("username").value;
    console.log(user);
    let pass = document.getElementById("password").value;
    console.log(pass);

    //If statements
    if (user == "Incorrect" && pass == "Incorrect") {
        alert("Sign-in Successful!!");
    } else if (pass !== "Incorrect" && user !== "Incorrect") {
        alert("Sign In Unsuccessful; The username and password is Incorrect");
    } else if (user !== "Incorrect") {
        alert("Sign In Unsuccessful; The username is Incorrect");
    } else if (pass !== "Incorrect") {
        alert("Sign In Unsuccessful; The password is Incorrect");

    //just in case...
    } else {
        alert("WHAT DID YOU DO TO CAUSE A WEBSITE MALFUNCTION?!");
    }
}

